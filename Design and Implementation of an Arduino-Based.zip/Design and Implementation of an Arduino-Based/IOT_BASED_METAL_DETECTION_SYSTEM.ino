#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include <DHT.h>

const int sensorPin = 25;
const int greenLED = 26;
const int redLED = 27;
const int buzzerPin = 14;
const int dhtPin = 15;

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SH1106G display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

DHT dht(dhtPin, DHT11);

int lastState = HIGH;
bool firstDetection = true;
unsigned long lastSensorRead = 0;
float temperature = 0;

void setup() {
  Serial.begin(115200);

  pinMode(sensorPin, INPUT_PULLUP);
  pinMode(greenLED, OUTPUT);
  pinMode(redLED, OUTPUT);
  pinMode(buzzerPin, OUTPUT);

  digitalWrite(greenLED, HIGH);
  digitalWrite(redLED, LOW);
  noTone(buzzerPin);

  Wire.begin(21, 22);

  if (!display.begin(0x3C, true)) {
    Serial.println("OLED not found");
    while (1);
  }

  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);

  dht.begin();

  //  Welcome screen 
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(0, 5);
  display.println("Metal");

  display.setCursor(0, 30);
  display.println("Detection");

  display.display();

  Serial.println("System Ready - Waiting for metal");
}

void readTemperature() {
  if (millis() - lastSensorRead >= 2000) {
    temperature = dht.readTemperature();

    if (isnan(temperature)) {
      Serial.println("DHT11 Read Error");
      temperature = 0;
    } else {
      Serial.print("Temperature: ");
      Serial.print(temperature);
      Serial.println("C");
    }
    lastSensorRead = millis();
  }
}

void loop() {
  int state = digitalRead(sensorPin);
  readTemperature();

  if (state != lastState) {

    if (state == LOW) {
      display.clearDisplay();

      //  METAL DETECTED 
      display.setTextSize(2);
      display.setCursor(0, 5);
      display.println("METAL");

      display.setCursor(0, 30);
      display.println("DETECTED");

      display.display();

      Serial.println("METAL DETECTED");

      tone(buzzerPin, 2000);
      digitalWrite(redLED, HIGH);
      firstDetection = false;
    }
    else {
      if (!firstDetection) {
        display.clearDisplay();

        //  NO METAL + TEMP 
        display.setTextSize(2);
        display.setCursor(0, 5);
        display.println("NO METAL");

        display.setCursor(0, 30);
        display.print("T:");
        display.print(temperature, 1);
        display.print("C");

        display.display();
      }

      Serial.println("NO METAL");

      noTone(buzzerPin);
      digitalWrite(redLED, LOW);
    }

    lastState = state;
  }
}